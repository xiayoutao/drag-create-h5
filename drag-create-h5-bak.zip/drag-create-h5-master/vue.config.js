const path = require('path');
const resolve = dir => path.join(__dirname, dir);

const isProd = process.env.NODE_ENV === 'production';

module.exports = {
  lintOnSave: !isProd,
  productionSourceMap: !isProd,
  publicPath: '/', // 相对路径
  outputDir: 'dist',
  devServer: {
    open: false,
    port: 8000,
    proxy: {
      '/api': {
        // target: 'http://127.0.0.1:1339',
        target: 'https://api-test.xiayoutao.wang',
        ws: true,
        changeOrigin: true
      }
    }
  },
  configureWebpack: {},
  chainWebpack: config => {
    config.plugins.delete('preload');
    config.plugins.delete('prefetch');

    config.resolve.alias
      .set('@', resolve('src'))
      .set('@cps', resolve('src/components'))
      .set('editor', resolve('src/editor'));

    config.module
      .rule('images')
      .use('url-loader')
      .loader('url-loader')
      .tap(options => Object.assign(options, { limit: 5120 }));
  },
  css: {
    loaderOptions: {
      sass: {
        additionalData: '@import "@/styles/variables.scss";@import "editor/styles/variables.scss";'
      },
      postcss: {
        plugins: []
      }
    }
  },
};
