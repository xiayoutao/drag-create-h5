<template>
  <router-view />
</template>


<script>
export default {
  name: 'DRAG-CREATE-APP',
}
</script>

<style lang="scss">
@import '@/styles/global.scss';
</style>
