<template>
  首页
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
</style>