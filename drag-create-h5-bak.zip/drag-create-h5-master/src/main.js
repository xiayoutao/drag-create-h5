import { createApp } from 'vue';
import App from './App.vue';
import store from './store';
import router from './router';
import ElementPlus from 'element-plus';
import 'element-plus/lib/theme-chalk/index.css';

import XiaEditor, { key, store as XiaEditorStore } from 'editor';

const app = createApp(App);
console.log('XiaEditorStore', XiaEditorStore);
app.use(router).use(store).use(XiaEditorStore, key).use(ElementPlus).use(XiaEditor).mount('#app');
app.config.devtools = process.env.NODE_ENV !== 'production';

console.log('app', app);